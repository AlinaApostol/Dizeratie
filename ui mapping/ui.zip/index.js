var app = angular.module("appMapping", []); 

app.controller("myCtrl", function($scope) {
    $scope.uploadXmlFile = function(){
        var file = document.getElementById('importFile').files[0],
        reader = new FileReader();
        reader.onloadend = function(e){
            $scope.data = e.target.result;
            $scope.contentXML = $scope.data;
            var preview = document.querySelector('#cont');

            var textc = document.createElement('textarea');
            textc.textContent = $scope.data;
            preview.appendChild(textc);
            $('#cont textarea').addClass('contentInfo');
            
        };
        reader.readAsBinaryString(file);
    };
});

